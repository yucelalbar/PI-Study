﻿/*
 * Author: Yucel Albar
 * for P.I. Works
 * 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace PiWorksQuestionnaire
{
    public class MusicService
    {
        public string PLAY_ID { get; set; }
        public Int32 SONG_ID { get; set; }
        public Int32 CLIENT_ID { get; set; }
        public DateTime PLAY_TS { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            using (StreamReader reader = new StreamReader("D:\\exhibitA-input.csv"))   // Input Location
            {
                var musicServiceList = new List<MusicService>();

                int lineCounter = 0;   // Line Counter

                while (!reader.EndOfStream)  //Read For exhibitA-input.csv
                {
                    var line = reader.ReadLine();

                    if (lineCounter.Equals(0)) /*first line is heading line. Ignore it*/
                    {
                        lineCounter++;
                        continue;
                    }

                    List<string> currList = line.Split('\t', '\n', ';').ToList();

                    MusicService musicService = new MusicService();
                    musicService.PLAY_ID = currList[0];
                    musicService.SONG_ID = Convert.ToInt32(currList[1]);
                    musicService.CLIENT_ID = Convert.ToInt32(currList[2]);
                    musicService.PLAY_TS = Convert.ToDateTime(currList[3]);
                    musicServiceList.Add(musicService);

                    lineCounter++;

                }

                var query = musicServiceList
                .Where(t => t.PLAY_TS >= new DateTime(2016, 8, 10) && t.PLAY_TS < new DateTime(2016, 8, 11))
                .Select(t => new { t.CLIENT_ID, t.SONG_ID })
                .Distinct()
                .GroupBy(c => c.CLIENT_ID)
                .Select(c => c.Count())
                .GroupBy(g => g)
                .Select(g => new { DISTINCT_PLAY_COUNT = g.Key, CLIENT_COUNT = g.Count() })
                .OrderByDescending(x => x.DISTINCT_PLAY_COUNT)
                .ToList();

                foreach (var y in query)
                {
                    Console.WriteLine("Distinct Play Count: " + y.DISTINCT_PLAY_COUNT + " Client Count: " + y.CLIENT_COUNT);
                }
            }
            Console.ReadKey();

        }
    }
}
